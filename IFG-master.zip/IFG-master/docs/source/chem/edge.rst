.. currentmodule:: chem.edge
.. codeauthor:: William Riddle

.. _edge-ref:

Edge
====

.. autoclass:: Edge
    :members:
    :member-order: