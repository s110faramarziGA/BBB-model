.. currentmodule:: chem.molecule
.. codeauthor:: William Riddle

.. _molecule-ref:

Molecule
========


.. autoclass:: Molecule
    :members:
    :member-order: