.. currentmodule:: chem.vertex
.. codeauthor:: William Riddle

.. _vertex-ref:

Vertex
======

.. autoclass:: Vertex
    :members:
    :member-order: