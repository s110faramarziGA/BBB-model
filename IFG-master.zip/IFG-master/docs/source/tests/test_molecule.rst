.. _test-molecule-ref:

Molecule Class Tests
====================

.. automodule:: tests.test_molecule
    :members:
    :member-order: